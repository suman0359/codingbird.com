<?php

class Checkout Extends CI_Controller {

    public function index() {
        $data = array();
        $data['header'] = $this->load->view('includes/header', $data);

        $data['checkout'] = $this->load->view('includes/checkout', $data);

        $data['footer'] = $this->load->view('includes/footer', $data);

        $this->load->view('index', $data);
    }

    public function process() {

        if ($cart = $this->cart->contents()):
            
            
            foreach ($cart as $item):
                @$grand_total = $grand_total + $item['subtotal'];
            
            endforeach;
            echo $grand_total;
        endif;

        if ($cart = $this->cart->contents()):

            foreach ($cart as $item):
                $grand_total = $grand_total + $item['subtotal'];
            endforeach;
        endif;

        $data = array();

        $data['product_id'] = $this->input->post('product_id');
        $data['product_name'] = $this->input->post('product_name');
        $data['product_price'] = $this->input->post('product_price');
        $data['product_quantity'] = $this->input->post('product_quantity');
        $data['product_sub_total'] = $this->input->post('product_sub_total');
        $data['product_total'] = $this->input->post('product_total');
    }

}
