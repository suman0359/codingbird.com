<?php include("includes/header.php") ?>

<div align="center"> 
    <img src="img/order page/Others banner.png" alt="Mountain View" style="width:2004px;height:238px" align="center;">
</div>
<div class="container order-page facebook-order">
    <div class="row">
        <div class="col-md-6">
            <img  src="img/order page/Others image.png" alt="">
        </div>

        <div class="col-md-6">
            <p>$  Depend on work </p>

            <h3>Others service</h3>
            <div class="description">
                <p align="justify">We are highly appreciate your your recent job, if you have more work need to done those is not include in our website like plugin, development, new site building etc. then please feel free to know us. We do respect you comments or any idea.</p>
                <ul>

                </ul>
            </div>
            <form action="">

            </form>

        </div>



    </div>
</div>

<?php include("includes/footer.php") ?>