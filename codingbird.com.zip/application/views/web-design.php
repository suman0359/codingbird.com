<?php include("includes/header.php") ?>

<div align="center"> 
    <img src="img/order page/web design.png" alt="Mountain View" style="width:2004px;height:238px" align="center;">
</div>

<div class="container order-page facebook-order">
    <div class="row">
        <div class="col-md-6">
            <img src="img/order page/Responsive-Web-Design.png" alt="">
        </div>

        <div class="col-md-6">
            <p>$150.00</p>

            <h3>We Designed beautiful website </h3>
            <div class="description">
                <p align="justify"> Website design should be at the heart of your business branding and presence because it can bring all the different aspects of your business strategies together. It lets you manage, distribute and share your services and offerings most efficiently. Your website improves customer care and lets you build a rapport with your clients. We take advantage of the cutting edge technological tools and our web designers’ creativity to provide you with a Responsive Website Design that is unique, professional, user-focused and world standard.Valid Email address.</p>



            </div>

            <p>
                <a href="">
                    <img src="img/order page/concern.png" alt="">
                </a>
            </p>

            <form action="">
                <div class="input-group"  style="float: left; width: 50px;">
                    <input type="number" value="1" class="form-control" size="4" style="text-align: center;">
                </div>
                <div class="button-group" >
                    <button class="btn btn-primary"  style="margin-left: 12px;">Add to cart</button>
                </div>
            </form>

        </div>



    </div>
</div>

<?php include("includes/footer.php") ?>