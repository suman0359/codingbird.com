<?php include("includes/header.php") ?>
    
<?php include("includes/hero-slider.php") ?>

<?php include("includes/how-its-works.php") ?>
       
<?php include("includes/pricing-plan.php") ?>

<?php //include("includes/portfolio.php") ?>

<?php include("includes/faq.php") ?> 

<?php include("includes/feedback.php") ?>
   
<?php include("includes/contacts.php") ?>
     
<?php include("includes/footer.php") ?>