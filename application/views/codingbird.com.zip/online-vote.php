<?php include("includes/header.php") ?>

<div align="center"> 
    <img src="img/order page/vote banner.png" alt="Mountain View" style="width:2004px;height:238px" align="center;">
</div>

<div class="container order-page facebook-order">
    <div class="row">
        <div class="col-md-6">
            <img src="img/order page/vote on.png" alt="">
        </div>

        <div class="col-md-6">
            <p>$44.99</p>

            <h3> Online Vote or Contest vote </h3>
            <div class="description">
                <p align="justify">We have online vote service also. our professional service make you more easy to win any contest, Email vote, IP vote, social media vote (Facebook, Twitter, Linkedin, Instagram) we provide From last two years, Or has big client base all over in the world. This service package starting from $30 (USD) For 120 votes. Once payment has cleared, we will be in-touch regarding design options, please provide a Valid Email address.</p>
                <ul>
                    <li>Packge one: $30 For 120 online vote</li>
                    <li>Packge one: $60 For 250 online vote</li>
                    <li>Packge one: $75 For 300 online vote</li>
                    <li> Packge one: $120 For 700 online vote </li>
                    <li> Packge one: $190 For 1000 online vote </li>
                    <li>Delivery Within 24 hours or your recommended times</li>
                </ul>
            </div>

            <p>
                <a href="">
                    <img src="img/order page/concern.png" alt="">
                </a>
            </p>

            <form action="">
                <div class="input-group"  style="float: left; width: 50px;">
                    <input type="number" value="1" class="form-control" size="4" style="text-align: center;">
                </div>
                <div class="button-group" >
                    <button class="btn btn-primary"  style="margin-left: 12px;">Add to cart</button>
                </div>
            </form>

        </div>



    </div>
</div>

<?php include("includes/footer.php") ?>