<!--feature-->
<section class="page-block" id="feature">
    <div class="container">
        <div class="row page-header">
            <h2 align="center">How It Works</h2>
            <span>No confusion</span>
        </div>
        <div class="row features">
            <div class="col-lg-4 col-md-4 col-sm-4">
                <div class="feature-img"><img src="img/How It Works/coding grap (1).png" width="124" height="120" alt="Editable colors"></div>
                <h3 align="center">Professionally Work</h3>
                <p align="justify">All of our Designer, Developer and specially Facebook Timeline Covers are professionally created by our dedicated graphic designers to ensure complete satisfaction. Each designs are industry related and we work with you to implement your very own content such as logo’s, imagery and text etc.</p>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4">
                <div class="feature-img"><img src="img/How It Works/Best Price.png" width="131" height="131" alt="All you need for start"></div>
                <h3 align="center">Best Reasonable Price</h3>
                <p align="justify">We have worldwide marketing plan to ensure our price are not affordable, highly competitive and some of the cheapest around. We provide professional design service for only fraction of the true cost. And make sure customer satisfaction first. Have a try.</p>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4">
                <div class="feature-img"><img src="img/How It Works/Time on delivery.png" width="72" height="72" alt="Clean code"></div>
                <h3 align="center">Delevery Around Time</h3>
                <p align="justify">We ensure all orders are delivered within 5 working days. Our average delivery time is 3 (depends on order) working days, however we very often deliver orders well before this estimate. If any problem arise during production, we will be in-touch in time..</p>
            </div>
        </div>
    </div>
</section>