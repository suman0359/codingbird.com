<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>Coding Bird</title>

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">

    <link href="css/icon-moon.css" rel="stylesheet" media="screen">
    <!--Animations-->
    <link href="css/animate.css" rel="stylesheet" media="screen">

    <link href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700" rel="stylesheet" type="text/css">
    
    <link rel="stylesheet" type="text/css" href="css/custom2.css">

    <link class="color-scheme" href="css/colors/color-default.css" rel="stylesheet" media="screen">
    
    <!--Modernizr-->
    <script src="js/libs/modernizr.custom.js"></script>

</head>
<body class="space-top">

 <div id="preloader"><div id="spinner"></div></div>

<header>
<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
         <div class="logo-section">
                <a href="index.php"><img src="img/CODING BIRD PSD 098cc9.png" alt="logo"></a>
            </div>
        </div>

        <div class="visible-xs-12">
            <ul class="nav navbar-nav">
                <li><a href="" class="btn btn-primary">Sign Up</a></li>
                <li><a href="" class="btn btn-primary">Login</a></li>
            </ul>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav main-menu">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#">Service</a></li>
            <li><a href="#">Portfolio</a></li>
            <li><a href="">About Us</a></li>
            <li><a href="">Contact Us</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Order Now <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="facebook-cover.php">Facebook Cover</a></li>
                <li><a href="twitter-cover.php">Twitter Cover</a></li>
                <li><a href="logo-design.php">Logo Design</a></li>
                <li><a href="web-design.php">Web design</a></li>
                <li><a href="banner-design.php">Banner Design</a></li>
                <li><a href="online-vote.php">Online Vote</a></li>
                <li><a href="others.php">Others</a></li>
              </ul>
            </li>
          </ul>
          

            <ul class="nav navbar-nav navbar-right login-button hidden-xs-12">
                    <li><a href="#" class="btn btn-primary">Sign Up</a></li>
                    <li><a href="#" class="btn btn-primary">Login</a></li>
            </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    </header>
    <div style="height: 85px;"></div>