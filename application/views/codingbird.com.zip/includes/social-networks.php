

<!--Social Networks-->
<section class="page-block" id="social">
    <div class="container">
        <div class="row page-header">
            <h2>Find us on social networks</h2>
            <span>Subtext for header</span>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="social-networks">
                    <a class="icon-facebook tooltipped" href="http://www.facebook.com/codingbirdcom" title="facebook">  </a>
                    <a class="icon-twitter tooltipped" href="https://twitter.com/icodingbird" title="Twitter"> </a>
                    <a class="icon-instagram tooltipped" href="#" title="Instagram"></a>
                    <a class="icon-google-plus tooltipped" href="#" title="Google+"></a>
                    <a class="icon-youtube tooltipped" href="#" title="Youtube"></a>
                    <a class="icon-tumblr tooltipped" href="#" title="Tumblr"></a>
                </div>
            </div>
        </div>
    </div>
</section>
