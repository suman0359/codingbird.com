<?php include("includes/header.php") ?>

<div class="facebook-banner">

</div>

<div class="container order-page facebook-order">
    <div class="row">
        <div class="col-md-6">
            <img src="img/order page/Banner.jpg" alt="">
        </div>

        <div class="col-md-6">
            <p>$44.99</p>

            <h3>Web Design Package</h3>
            <div class="description">
                <p align="justify"> Our Professional Banner Design package comes with the following as standard, optional extras are priced accordingly below. NOTE: Once payment has cleared, we will be in-touch regarding design options, please provide a VALID Email address.</p>
                <ul>
                    <li>TWO Custom Designed Banner Design</li>
                    <li>TWO Custom Designed Profile Pictures</li>
                    <li>All files delivered in .JPG format</li>
                    <li>Delivery: Between 1-7 working days</li>
                </ul>
            </div>

            <p>
                <a href="">
                    <img src="img/order page/order-contact.png" alt="">
                </a>
            </p>

            <form action="">
                <div class="input-group"  style="float: left; width: 50px;">
                    <input type="number" value="1" class="form-control" size="4" style="text-align: center;">
                </div>
                <div class="button-group" >
                    <button class="btn btn-primary"  style="margin-left: 12px;">Add to cart</button>
                </div>
            </form>

        </div>



    </div>
</div>

<?php include("includes/footer.php") ?>